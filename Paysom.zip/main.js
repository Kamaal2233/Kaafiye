let magac= Mohamed;
console.log(magac);